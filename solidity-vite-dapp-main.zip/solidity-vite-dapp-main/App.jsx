import { useState, useEffect } from "react";
import { ethers } from "ethers";
import { Button, TextField, Container, Typography } from "@mui/material";

// Replace with your deployed contract address
const CONTRACT_ADDRESS = "YOUR_DEPLOYED_CONTRACT_ADDRESS";
const CONTRACT_ABI = [
  {
    "inputs": [],
    "name": "getValues",
    "outputs": [
      { "internalType": "int256", "name": "", "type": "int256" },
      { "internalType": "string", "name": "", "type": "string" }
    ],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [
      { "internalType": "int256", "name": "_number", "type": "int256" },
      { "internalType": "string", "name": "_text", "type": "string" }
    ],
    "name": "updateValues",
    "outputs": [],
    "stateMutability": "nonpayable",
    "type": "function"
  }
];

function App() {
  const [number, setNumber] = useState("");
  const [text, setText] = useState("");
  const [provider, setProvider] = useState(null);
  const [contract, setContract] = useState(null);
  const [account, setAccount] = useState(null);

  useEffect(() => {
    async function connectWallet() {
      if (window.ethereum) {
        const provider = new ethers.BrowserProvider(window.ethereum);
        const signer = await provider.getSigner();
        const contract = new ethers.Contract(CONTRACT_ADDRESS, CONTRACT_ABI, signer);

        setProvider(provider);
        setContract(contract);

        const accounts = await provider.send("eth_requestAccounts", []);
        setAccount(accounts[0]);

        const [currentNumber, currentText] = await contract.getValues();
        setNumber(currentNumber.toString());
        setText(currentText);
      } else {
        alert("Please install MetaMask!");
      }
    }
    connectWallet();
  }, []);

  const updateValues = async () => {
    if (!contract) return;
    try {
      const tx = await contract.updateValues(Number(number), text);
      await tx.wait();
      alert("Values updated!");
    } catch (error) {
      console.error("Transaction failed:", error);
    }
  };

  return (
    <Container maxWidth="sm">
      <Typography variant="h4" gutterBottom>Editable Values</Typography>
      <Typography variant="subtitle1">Connected Wallet: {account}</Typography>
      <TextField
        label="Number"
        variant="outlined"
        fullWidth
        margin="normal"
        value={number}
        onChange={(e) => setNumber(e.target.value)}
      />
      <TextField
        label="Text"
        variant="outlined"
        fullWidth
        margin="normal"
        value={text}
        onChange={(e) => setText(e.target.value)}
      />
      <Button variant="contained" color="primary" fullWidth onClick={updateValues}>
        Update Values
      </Button>
    </Container>
  );
}

export default App;
